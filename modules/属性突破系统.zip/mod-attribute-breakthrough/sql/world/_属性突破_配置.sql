-- 属性突破系统 - 配置表
-- 属性类型ID基于源码 ItemTemplate.h (ItemModType) 和 Unit.h (UnitMods) 枚举定义

DROP TABLE IF EXISTS `_属性突破_配置`;
CREATE TABLE `_属性突破_配置` (
    `id` INT UNSIGNED NOT NULL AUTO_INCREMENT COMMENT '自增ID',
    `属性类型` TINYINT UNSIGNED NOT NULL COMMENT '属性类型ID',
    `属性名称` VARCHAR(32) NOT NULL DEFAULT '' COMMENT '属性中文名称',
    `魂属性名称` VARCHAR(32) NOT NULL DEFAULT '' COMMENT '魂属性中文名称',
    `单位值` BIGINT NOT NULL DEFAULT 2000000000 COMMENT '魂属性单位值（默认20亿）',
    `启用` TINYINT UNSIGNED NOT NULL DEFAULT 1 COMMENT '是否启用',
    `备注` VARCHAR(255) DEFAULT '' COMMENT '备注说明',
    PRIMARY KEY (`id`),
    UNIQUE KEY `idx_属性类型` (`属性类型`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT='属性突破系统 - 配置表';

-- 插入属性配置
-- ItemModType 枚举 (0-48)
INSERT INTO `_属性突破_配置` (`属性类型`, `属性名称`, `魂属性名称`, `单位值`, `启用`, `备注`) VALUES
-- 基础属性 (ItemModType)
(0, '法力值', '魂蓝', 2000000000, 1, 'ITEM_MOD_MANA'),
(1, '生命值', '魂血', 2000000000, 1, 'ITEM_MOD_HEALTH'),
(3, '敏捷', '魂敏', 2000000000, 1, 'ITEM_MOD_AGILITY'),
(4, '力量', '魂力', 2000000000, 1, 'ITEM_MOD_STRENGTH'),
(5, '智力', '魂智', 2000000000, 1, 'ITEM_MOD_INTELLECT'),
(6, '精神', '魂精', 2000000000, 1, 'ITEM_MOD_SPIRIT'),
(7, '耐力', '魂耐', 2000000000, 1, 'ITEM_MOD_STAMINA'),
-- 防御评级
(12, '防御等级', '魂防', 2000000000, 1, 'ITEM_MOD_DEFENSE_SKILL_RATING'),
(13, '躲闪等级', '魂闪', 2000000000, 1, 'ITEM_MOD_DODGE_RATING'),
(14, '招架等级', '魂招', 2000000000, 1, 'ITEM_MOD_PARRY_RATING'),
(15, '格挡等级', '魂挡', 2000000000, 1, 'ITEM_MOD_BLOCK_RATING'),
-- 命中评级
(16, '近战命中等级', '魂近命', 2000000000, 1, 'ITEM_MOD_HIT_MELEE_RATING'),
(17, '远程命中等级', '魂远命', 2000000000, 1, 'ITEM_MOD_HIT_RANGED_RATING'),
(18, '法术命中等级', '魂法命', 2000000000, 1, 'ITEM_MOD_HIT_SPELL_RATING'),
-- 暴击评级
(19, '近战暴击等级', '魂近暴', 2000000000, 1, 'ITEM_MOD_CRIT_MELEE_RATING'),
(20, '远程暴击等级', '魂远暴', 2000000000, 1, 'ITEM_MOD_CRIT_RANGED_RATING'),
(21, '法术暴击等级', '魂法暴', 2000000000, 1, 'ITEM_MOD_CRIT_SPELL_RATING'),
-- 被命中评级
(22, '近战被命中等级', '魂近躲', 2000000000, 0, 'ITEM_MOD_HIT_TAKEN_MELEE_RATING'),
(23, '远程被命中等级', '魂远躲', 2000000000, 0, 'ITEM_MOD_HIT_TAKEN_RANGED_RATING'),
(24, '法术被命中等级', '魂法躲', 2000000000, 0, 'ITEM_MOD_HIT_TAKEN_SPELL_RATING'),
-- 被暴击评级
(25, '近战被暴击等级', '魂近韧', 2000000000, 0, 'ITEM_MOD_CRIT_TAKEN_MELEE_RATING'),
(26, '远程被暴击等级', '魂远韧', 2000000000, 0, 'ITEM_MOD_CRIT_TAKEN_RANGED_RATING'),
(27, '法术被暴击等级', '魂法韧', 2000000000, 0, 'ITEM_MOD_CRIT_TAKEN_SPELL_RATING'),
-- 急速评级
(28, '近战急速等级', '魂近速', 2000000000, 1, 'ITEM_MOD_HASTE_MELEE_RATING'),
(29, '远程急速等级', '魂远速', 2000000000, 1, 'ITEM_MOD_HASTE_RANGED_RATING'),
(30, '法术急速等级', '魂法速', 2000000000, 1, 'ITEM_MOD_HASTE_SPELL_RATING'),
-- 通用评级
(31, '命中等级', '魂命', 2000000000, 1, 'ITEM_MOD_HIT_RATING'),
(32, '暴击等级', '魂暴', 2000000000, 1, 'ITEM_MOD_CRIT_RATING'),
(33, '被命中等级', '魂躲', 2000000000, 0, 'ITEM_MOD_HIT_TAKEN_RATING'),
(34, '被暴击等级', '魂韧', 2000000000, 0, 'ITEM_MOD_CRIT_TAKEN_RATING'),
(35, '韧性等级', '魂韧性', 2000000000, 1, 'ITEM_MOD_RESILIENCE_RATING'),
(36, '急速等级', '魂速', 2000000000, 1, 'ITEM_MOD_HASTE_RATING'),
(37, '精准等级', '魂准', 2000000000, 1, 'ITEM_MOD_EXPERTISE_RATING'),
-- 攻击强度
(38, '攻击强度', '魂攻', 2000000000, 1, 'ITEM_MOD_ATTACK_POWER'),
(39, '远程攻击强度', '魂远攻', 2000000000, 1, 'ITEM_MOD_RANGED_ATTACK_POWER'),
-- 法术属性
(41, '法术治疗', '魂疗', 2000000000, 0, 'ITEM_MOD_SPELL_HEALING_DONE - deprecated'),
(42, '法术伤害', '魂法伤', 2000000000, 0, 'ITEM_MOD_SPELL_DAMAGE_DONE - deprecated'),
(43, '法力回复', '魂蓝回', 2000000000, 1, 'ITEM_MOD_MANA_REGENERATION'),
(44, '护甲穿透等级', '魂甲穿', 2000000000, 1, 'ITEM_MOD_ARMOR_PENETRATION_RATING'),
(45, '法术强度', '魂法', 2000000000, 1, 'ITEM_MOD_SPELL_POWER'),
(46, '生命值回复', '魂血回', 2000000000, 1, 'ITEM_MOD_HEALTH_REGEN'),
(47, '法术穿透', '魂法穿', 2000000000, 1, 'ITEM_MOD_SPELL_PENETRATION'),
(48, '格挡值', '魂挡值', 2000000000, 1, 'ITEM_MOD_BLOCK_VALUE'),

-- 扩展属性 (UnitMods 枚举, 使用 50+ 作为自定义ID)
-- 护甲和抗性
(50, '护甲', '魂甲', 2000000000, 1, 'UNIT_MOD_ARMOR'),
(51, '神圣抗性', '魂圣抗', 2000000000, 1, 'UNIT_MOD_RESISTANCE_HOLY'),
(52, '火焰抗性', '魂火抗', 2000000000, 1, 'UNIT_MOD_RESISTANCE_FIRE'),
(53, '自然抗性', '魂自抗', 2000000000, 1, 'UNIT_MOD_RESISTANCE_NATURE'),
(54, '冰霜抗性', '魂冰抗', 2000000000, 1, 'UNIT_MOD_RESISTANCE_FROST'),
(55, '暗影抗性', '魂暗抗', 2000000000, 1, 'UNIT_MOD_RESISTANCE_SHADOW'),
(56, '奥术抗性', '魂奥抗', 2000000000, 1, 'UNIT_MOD_RESISTANCE_ARCANE'),
-- 伤害
(57, '主手伤害', '魂主伤', 2000000000, 1, 'UNIT_MOD_DAMAGE_MAINHAND'),
(58, '副手伤害', '魂副伤', 2000000000, 1, 'UNIT_MOD_DAMAGE_OFFHAND'),
(59, '远程伤害', '魂远伤', 2000000000, 1, 'UNIT_MOD_DAMAGE_RANGED'),
-- 防御值
(60, '防御值', '魂防值', 2000000000, 1, '防御技能值');
