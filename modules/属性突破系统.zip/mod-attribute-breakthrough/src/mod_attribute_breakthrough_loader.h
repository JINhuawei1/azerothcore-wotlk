/*
 * 属性突破系统 - 模块加载器
 */

#ifndef _ATTRIBUTE_BREAKTHROUGH_LOADER_H_
#define _ATTRIBUTE_BREAKTHROUGH_LOADER_H_

// 声明脚本添加函数
void AddSC_AttributeBreakthroughModule();
void AddSC_AttributeBreakthroughCommands();

// 模块加载入口
void Addmod_attribute_breakthroughScripts()
{
    AddSC_AttributeBreakthroughModule();
    AddSC_AttributeBreakthroughCommands();
}

#endif // _ATTRIBUTE_BREAKTHROUGH_LOADER_H_
