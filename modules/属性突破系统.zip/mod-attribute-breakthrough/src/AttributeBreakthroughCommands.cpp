/*
 * 属性突破系统 - GM命令
 * 基于源码 SharedDefines.h 和 Unit.h 中的枚举定义
 */

#include "AttributeBreakthrough.h"
#include "ScriptMgr.h"
#include "Chat.h"
#include "Player.h"
#include "Language.h"

using namespace Acore::ChatCommands;

class AttributeBreakthroughCommandScript : public CommandScript
{
public:
    AttributeBreakthroughCommandScript() : CommandScript("AttributeBreakthroughCommandScript") { }

    ChatCommandTable GetCommands() const override
    {
        static ChatCommandTable soulCommandTable =
        {
            { "info",    HandleSoulInfoCommand,    SEC_PLAYER,     Console::No },
            { "set",     HandleSoulSetCommand,     SEC_GAMEMASTER, Console::No },
            { "add",     HandleSoulAddCommand,     SEC_GAMEMASTER, Console::No },
            { "reset",   HandleSoulResetCommand,   SEC_GAMEMASTER, Console::No },
            { "list",    HandleSoulListCommand,    SEC_PLAYER,     Console::No },
            { "reload",  HandleSoulReloadCommand,  SEC_ADMINISTRATOR, Console::Yes },
        };

        static ChatCommandTable commandTable =
        {
            { "soul", soulCommandTable },
        };

        return commandTable;
    }

    // 查看魂属性信息
    static bool HandleSoulInfoCommand(ChatHandler* handler, Optional<PlayerIdentifier> target)
    {
        Player* player = nullptr;

        if (target)
            player = target->GetConnectedPlayer();
        else
            player = handler->GetPlayer();

        if (!player)
        {
            handler->SendSysMessage("找不到目标玩家");
            return false;
        }

        if (!sAttributeBreakthroughMgr->IsEnabled())
        {
            handler->SendSysMessage("属性突破系统未启用");
            return false;
        }

        std::string display = sAttributeBreakthroughMgr->GetAllSoulAttributesDisplay(player);
        handler->SendSysMessage(display.c_str());

        return true;
    }

    // 列出所有属性类型
    static bool HandleSoulListCommand(ChatHandler* handler)
    {
        handler->SendSysMessage("|cff00ff00=== 属性突破 - 属性类型列表 ===|r");

        handler->SendSysMessage("|cff00ffff[基础属性 0-4]|r");
        handler->SendSysMessage("  0=魂力, 1=魂敏, 2=魂耐, 3=魂智, 4=魂精");

        handler->SendSysMessage("|cff00ffff[资源属性 5-11]|r");
        handler->SendSysMessage("  5=魂血, 6=魂蓝, 7=魂怒, 8=魂集, 9=魂能, 10=魂乐, 11=魂符");

        handler->SendSysMessage("|cff00ffff[抗性属性 12-18]|r");
        handler->SendSysMessage("  12=魂甲, 13=魂圣抗, 14=魂火抗, 15=魂自抗, 16=魂冰抗, 17=魂暗抗, 18=魂奥抗");

        handler->SendSysMessage("|cff00ffff[攻击属性 19-25]|r");
        handler->SendSysMessage("  19=魂攻, 20=魂远攻, 21=魂法, 22=魂疗, 23=魂主伤, 24=魂副伤, 25=魂远伤");

        handler->SendSysMessage("|cff00ffff[战斗评级 26-50]|r");
        handler->SendSysMessage("  26=魂武技, 27=魂防技, 28=魂闪, 29=魂招, 30=魂挡");
        handler->SendSysMessage("  31=魂近命, 32=魂远命, 33=魂法命");
        handler->SendSysMessage("  34=魂近暴, 35=魂远暴, 36=魂法暴");
        handler->SendSysMessage("  37=魂近躲, 38=魂远躲, 39=魂法躲");
        handler->SendSysMessage("  40=魂近韧, 41=魂远韧, 42=魂法韧");
        handler->SendSysMessage("  43=魂近速, 44=魂远速, 45=魂法速");
        handler->SendSysMessage("  46=魂主武, 47=魂副武, 48=魂远武");
        handler->SendSysMessage("  49=魂准, 50=魂穿");

        handler->SendSysMessage("|cff00ffff[其他属性 51-60]|r");
        handler->SendSysMessage("  51=魂韧, 52=魂挡值, 53=魂蓝回, 54=魂血回, 55=魂伤");
        handler->SendSysMessage("  56=魂疗加, 57=魂减伤, 58=魂速, 59=魂攻速, 60=魂施速");

        return true;
    }

    // 设置魂属性
    // 用法: .soul set <属性类型> <魂值> [玩家名]
    static bool HandleSoulSetCommand(ChatHandler* handler, uint32 attrType, int64 soulValue, Optional<PlayerIdentifier> target)
    {
        Player* player = nullptr;

        if (target)
            player = target->GetConnectedPlayer();
        else
            player = handler->GetPlayer();

        if (!player)
        {
            handler->SendSysMessage("找不到目标玩家");
            return false;
        }

        if (!sAttributeBreakthroughMgr->IsEnabled())
        {
            handler->SendSysMessage("属性突破系统未启用");
            return false;
        }

        if (attrType >= SOUL_ATTR_MAX)
        {
            handler->PSendSysMessage("无效的属性类型。有效范围: 0-%d", SOUL_ATTR_MAX - 1);
            handler->SendSysMessage("使用 |cffffd700.soul list|r 查看所有属性类型");
            return false;
        }

        SoulAttributeType type = static_cast<SoulAttributeType>(attrType);

        if (sAttributeBreakthroughMgr->SetPlayerSoulAttribute(player, type, soulValue))
        {
            handler->PSendSysMessage("已将玩家 %s 的 %s 设置为 %lld",
                player->GetName().c_str(), SoulAttributeNames[attrType], soulValue);

            // 保存数据
            sAttributeBreakthroughMgr->SavePlayerData(player);

            // 刷新玩家属性
            player->UpdateAllStats();

            return true;
        }

        handler->SendSysMessage("设置魂属性失败");
        return false;
    }

    // 增加魂属性
    // 用法: .soul add <属性类型> <增加的魂值> [玩家名]
    static bool HandleSoulAddCommand(ChatHandler* handler, uint32 attrType, int64 addValue, Optional<PlayerIdentifier> target)
    {
        Player* player = nullptr;

        if (target)
            player = target->GetConnectedPlayer();
        else
            player = handler->GetPlayer();

        if (!player)
        {
            handler->SendSysMessage("找不到目标玩家");
            return false;
        }

        if (!sAttributeBreakthroughMgr->IsEnabled())
        {
            handler->SendSysMessage("属性突破系统未启用");
            return false;
        }

        if (attrType >= SOUL_ATTR_MAX)
        {
            handler->PSendSysMessage("无效的属性类型。有效范围: 0-%d", SOUL_ATTR_MAX - 1);
            handler->SendSysMessage("使用 |cffffd700.soul list|r 查看所有属性类型");
            return false;
        }

        SoulAttributeType type = static_cast<SoulAttributeType>(attrType);

        if (sAttributeBreakthroughMgr->AddPlayerSoulAttribute(player, type, addValue))
        {
            PlayerSoulData* data = sAttributeBreakthroughMgr->GetPlayerData(player->GetGUID().GetCounter());
            int64 newValue = data ? data->GetSoulValue(type) : 0;

            handler->PSendSysMessage("已为玩家 %s 增加 %lld %s，当前值: %lld",
                player->GetName().c_str(), addValue, SoulAttributeNames[attrType], newValue);

            // 保存数据
            sAttributeBreakthroughMgr->SavePlayerData(player);

            // 刷新玩家属性
            player->UpdateAllStats();

            return true;
        }

        handler->SendSysMessage("增加魂属性失败");
        return false;
    }

    // 重置魂属性
    // 用法: .soul reset [玩家名]
    static bool HandleSoulResetCommand(ChatHandler* handler, Optional<PlayerIdentifier> target)
    {
        Player* player = nullptr;

        if (target)
            player = target->GetConnectedPlayer();
        else
            player = handler->GetPlayer();

        if (!player)
        {
            handler->SendSysMessage("找不到目标玩家");
            return false;
        }

        if (!sAttributeBreakthroughMgr->IsEnabled())
        {
            handler->SendSysMessage("属性突破系统未启用");
            return false;
        }

        uint32 playerGuid = player->GetGUID().GetCounter();

        // 重置所有魂属性为0
        for (int i = 0; i < SOUL_ATTR_MAX; ++i)
        {
            sAttributeBreakthroughMgr->SetPlayerSoulAttribute(player, static_cast<SoulAttributeType>(i), 0);
        }

        // 保存数据
        sAttributeBreakthroughMgr->SavePlayerData(player);

        // 刷新玩家属性
        player->UpdateAllStats();

        handler->PSendSysMessage("已重置玩家 %s 的所有魂属性", player->GetName().c_str());
        return true;
    }

    // 重载配置
    static bool HandleSoulReloadCommand(ChatHandler* handler)
    {
        sAttributeBreakthroughMgr->LoadConfig();
        handler->SendSysMessage("属性突破系统配置已重载");
        return true;
    }
};

void AddSC_AttributeBreakthroughCommands()
{
    new AttributeBreakthroughCommandScript();
}
