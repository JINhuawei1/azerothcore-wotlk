/*
 * 属性突破系统 - 核心实现
 * 属性类型基于源码 ItemTemplate.h 中的 ItemModType 枚举定义
 */

#include "AttributeBreakthrough.h"
#include "Log.h"
#include "Configuration/Config.h"
#include "DatabaseEnv.h"
#include "Chat.h"
#include <sstream>
#include <iomanip>

// ==================== AttributeBreakthroughMgr 实现 ====================

AttributeBreakthroughMgr::AttributeBreakthroughMgr() : _enabled(true)
{
    _attributeEnabled.fill(false);
}

AttributeBreakthroughMgr::~AttributeBreakthroughMgr()
{
    _playerData.clear();
}

AttributeBreakthroughMgr* AttributeBreakthroughMgr::instance()
{
    static AttributeBreakthroughMgr instance;
    return &instance;
}

void AttributeBreakthroughMgr::LoadConfig()
{
    _enabled = sConfigMgr->GetOption<bool>("AttributeBreakthrough.Enable", true);

    if (!_enabled)
    {
        LOG_INFO("server.loading", ">> 属性突破系统已禁用");
        return;
    }

    // 从数据库加载属性启用配置
    QueryResult result = WorldDatabase.Query("SELECT `属性类型`, `启用` FROM `_属性突破_配置`");
    if (result)
    {
        do
        {
            Field* fields = result->Fetch();
            uint8 attrType = fields[0].Get<uint8>();
            bool enabled = fields[1].Get<uint8>() > 0;

            if (attrType < MAX_SOUL_ATTR)
            {
                _attributeEnabled[attrType] = enabled;
            }
        } while (result->NextRow());

        LOG_INFO("server.loading", ">> 属性突破系统已启用，加载了属性配置");
    }
    else
    {
        // 如果没有配置表，默认启用基础属性
        _attributeEnabled[SOUL_ATTR_MANA] = true;
        _attributeEnabled[SOUL_ATTR_HEALTH] = true;
        _attributeEnabled[SOUL_ATTR_AGILITY] = true;
        _attributeEnabled[SOUL_ATTR_STRENGTH] = true;
        _attributeEnabled[SOUL_ATTR_INTELLECT] = true;
        _attributeEnabled[SOUL_ATTR_SPIRIT] = true;
        _attributeEnabled[SOUL_ATTR_STAMINA] = true;
        _attributeEnabled[SOUL_ATTR_ATTACK_POWER] = true;
        _attributeEnabled[SOUL_ATTR_SPELL_POWER] = true;

        LOG_INFO("server.loading", ">> 属性突破系统已启用（使用默认配置）");
    }
}

bool AttributeBreakthroughMgr::IsAttributeEnabled(uint8 type) const
{
    if (type >= MAX_SOUL_ATTR)
        return false;
    return _attributeEnabled[type];
}

const char* AttributeBreakthroughMgr::GetAttributeName(uint8 type) const
{
    if (type >= MAX_SOUL_ATTR)
        return "";
    return SoulAttributeNames[type];
}

void AttributeBreakthroughMgr::LoadPlayerData(Player* player)
{
    if (!player || !_enabled)
        return;

    uint32 playerGuid = player->GetGUID().GetCounter();

    // 初始化玩家数据
    _playerData[playerGuid] = PlayerSoulData();
    _playerData[playerGuid].playerGuid = playerGuid;

    // 从数据库加载
    QueryResult result = CharacterDatabase.Query(
        "SELECT * FROM `_属性突破_玩家数据` WHERE `guid` = {}", playerGuid);

    if (result)
    {
        Field* fields = result->Fetch();
        PlayerSoulData& data = _playerData[playerGuid];

        // 字段顺序: guid, soul_0..soul_48, remainder_0..remainder_48
        for (uint8 i = 0; i < MAX_SOUL_ATTR; ++i)
        {
            data.soulValues[i] = fields[1 + i].Get<int64>();
        }
        for (uint8 i = 0; i < MAX_SOUL_ATTR; ++i)
        {
            data.remainderValues[i] = fields[1 + MAX_SOUL_ATTR + i].Get<int32>();
        }

        LOG_DEBUG("module", "属性突破: 为玩家 {} 加载数据成功", player->GetName());
    }
}

void AttributeBreakthroughMgr::SavePlayerData(Player* player)
{
    if (!player || !_enabled)
        return;

    uint32 playerGuid = player->GetGUID().GetCounter();
    auto it = _playerData.find(playerGuid);
    if (it == _playerData.end())
        return;

    const PlayerSoulData& data = it->second;

    // 构建动态SQL
    std::stringstream ss;
    ss << "REPLACE INTO `_属性突破_玩家数据` (`guid`";

    for (uint8 i = 0; i < MAX_SOUL_ATTR; ++i)
        ss << ", `soul_" << (int)i << "`";
    for (uint8 i = 0; i < MAX_SOUL_ATTR; ++i)
        ss << ", `remainder_" << (int)i << "`";

    ss << ") VALUES (" << playerGuid;

    for (uint8 i = 0; i < MAX_SOUL_ATTR; ++i)
        ss << ", " << data.soulValues[i];
    for (uint8 i = 0; i < MAX_SOUL_ATTR; ++i)
        ss << ", " << data.remainderValues[i];

    ss << ")";

    CharacterDatabase.Execute(ss.str().c_str());
    LOG_DEBUG("module", "属性突破: 为玩家 {} 保存数据成功", player->GetName());
}

void AttributeBreakthroughMgr::OnPlayerLogout(uint32 playerGuid)
{
    _playerData.erase(playerGuid);
}

PlayerSoulData* AttributeBreakthroughMgr::GetPlayerData(uint32 playerGuid)
{
    auto it = _playerData.find(playerGuid);
    if (it == _playerData.end())
        return nullptr;
    return &(it->second);
}

const PlayerSoulData* AttributeBreakthroughMgr::GetPlayerData(uint32 playerGuid) const
{
    auto it = _playerData.find(playerGuid);
    if (it == _playerData.end())
        return nullptr;
    return &(it->second);
}

void AttributeBreakthroughMgr::ConvertToSoulAttribute(int64 totalValue, int64& soulValue, int32& remainder)
{
    soulValue = totalValue / SOUL_UNIT;
    remainder = static_cast<int32>(totalValue % SOUL_UNIT);
}

int64 AttributeBreakthroughMgr::ConvertFromSoulAttribute(int64 soulValue, int32 remainder)
{
    return soulValue * SOUL_UNIT + remainder;
}

int32 AttributeBreakthroughMgr::GetClientSafeValue(int64 totalValue)
{
    if (totalValue > MAX_SAFE_INT32)
        return MAX_SAFE_INT32;
    if (totalValue < -MAX_SAFE_INT32)
        return -MAX_SAFE_INT32;
    return static_cast<int32>(totalValue);
}

void AttributeBreakthroughMgr::UpdatePlayerSoulAttributes(Player* player)
{
    if (!player || !_enabled)
        return;

    uint32 playerGuid = player->GetGUID().GetCounter();
    PlayerSoulData* data = GetPlayerData(playerGuid);
    if (!data)
        return;

    // 检测属性溢出并自动转换为魂属性
    // 这里可以根据需要添加自动检测逻辑
}

void AttributeBreakthroughMgr::ApplySoulAttributeBonus(Player* player, uint8 type, int64 bonusSoulValue)
{
    if (!player || !_enabled || type >= MAX_SOUL_ATTR)
        return;

    uint32 playerGuid = player->GetGUID().GetCounter();
    PlayerSoulData* data = GetPlayerData(playerGuid);
    if (!data)
        return;

    data->soulValues[type] += bonusSoulValue;
}

std::string AttributeBreakthroughMgr::GetAttributeDisplayString(Player* player, uint8 type)
{
    if (!player || !_enabled)
        return "系统未启用";

    uint32 playerGuid = player->GetGUID().GetCounter();
    const PlayerSoulData* data = GetPlayerData(playerGuid);
    if (!data)
        return "无数据";

    int64 soulValue = data->GetSoulValue(type);
    int32 remainder = data->GetRemainderValue(type);

    std::stringstream ss;
    if (soulValue > 0)
        ss << "|cffff00ff" << soulValue << GetAttributeName(type) << "|r + ";
    ss << "|cffffd700" << remainder << "|r";

    return ss.str();
}

std::string AttributeBreakthroughMgr::GetAllSoulAttributesDisplay(Player* player)
{
    if (!player || !_enabled)
        return "属性突破系统未启用";

    uint32 playerGuid = player->GetGUID().GetCounter();
    const PlayerSoulData* data = GetPlayerData(playerGuid);
    if (!data)
        return "无玩家数据";

    std::stringstream ss;
    ss << "|cff00ff00=== 属性突破 - 魂属性 ===|r\n";

    bool hasAny = false;
    for (uint8 i = 0; i < MAX_SOUL_ATTR; ++i)
    {
        // 跳过未使用的属性类型
        if (strlen(SoulAttributeNames[i]) == 0)
            continue;

        int64 soulValue = data->GetSoulValue(i);
        int32 remainder = data->GetRemainderValue(i);

        if (soulValue > 0 || remainder > 0)
        {
            hasAny = true;
            ss << "  " << SoulAttributeNames[i] << ": ";
            if (soulValue > 0)
                ss << "|cffff00ff" << soulValue << "魂|r + ";
            ss << "|cffffd700" << remainder << "|r\n";
        }
    }

    if (!hasAny)
        ss << "  暂无魂属性\n";

    return ss.str();
}

bool AttributeBreakthroughMgr::SetPlayerSoulAttribute(Player* player, uint8 type, int64 soulValue)
{
    if (!player || !_enabled || type >= MAX_SOUL_ATTR)
        return false;

    uint32 playerGuid = player->GetGUID().GetCounter();
    PlayerSoulData* data = GetPlayerData(playerGuid);
    if (!data)
    {
        _playerData[playerGuid] = PlayerSoulData();
        _playerData[playerGuid].playerGuid = playerGuid;
        data = &_playerData[playerGuid];
    }

    data->SetSoulValue(type, soulValue);
    return true;
}

bool AttributeBreakthroughMgr::AddPlayerSoulAttribute(Player* player, uint8 type, int64 addSoulValue)
{
    if (!player || !_enabled || type >= MAX_SOUL_ATTR)
        return false;

    uint32 playerGuid = player->GetGUID().GetCounter();
    PlayerSoulData* data = GetPlayerData(playerGuid);
    if (!data)
    {
        _playerData[playerGuid] = PlayerSoulData();
        _playerData[playerGuid].playerGuid = playerGuid;
        data = &_playerData[playerGuid];
    }

    int64 currentValue = data->GetSoulValue(type);
    data->SetSoulValue(type, currentValue + addSoulValue);
    return true;
}
