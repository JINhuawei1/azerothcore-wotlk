/*
 * 属性突破系统 (Attribute Breakthrough System)
 *
 * 功能说明：
 * 1. 将超大属性值转换为"魂属性"单位，避免int32溢出
 * 2. 1魂力 = 20亿力量，1魂敏 = 20亿敏捷，以此类推
 * 3. 服务器内部使用int64/double计算，客户端显示魂属性单位
 * 4. 支持数据库配置和GM命令管理
 *
 * 属性类型基于源码 ItemTemplate.h 中的 ItemModType 枚举定义
 */

#ifndef _ATTRIBUTE_BREAKTHROUGH_H_
#define _ATTRIBUTE_BREAKTHROUGH_H_

#include "Common.h"
#include "Player.h"
#include "DatabaseEnv.h"
#include <map>
#include <unordered_map>
#include <string>
#include <array>

// 魂属性单位 = 20亿 (2,000,000,000)
constexpr int64 SOUL_UNIT = 2000000000LL;

// 最大安全int32值
constexpr int32 MAX_SAFE_INT32 = 2147483647;

// 最大属性类型数量 (基于 ItemModType 枚举 0-48 + 扩展属性 50-60)
constexpr uint8 MAX_SOUL_ATTR = 61;

// 魂属性类型枚举 - 基于源码 ItemTemplate.h 中的 ItemModType
enum SoulAttributeType
{
    SOUL_ATTR_MANA                     = 0,   // 魂蓝 - ITEM_MOD_MANA
    SOUL_ATTR_HEALTH                   = 1,   // 魂血 - ITEM_MOD_HEALTH
    // 2 未使用
    SOUL_ATTR_AGILITY                  = 3,   // 魂敏 - ITEM_MOD_AGILITY
    SOUL_ATTR_STRENGTH                 = 4,   // 魂力 - ITEM_MOD_STRENGTH
    SOUL_ATTR_INTELLECT                = 5,   // 魂智 - ITEM_MOD_INTELLECT
    SOUL_ATTR_SPIRIT                   = 6,   // 魂精 - ITEM_MOD_SPIRIT
    SOUL_ATTR_STAMINA                  = 7,   // 魂耐 - ITEM_MOD_STAMINA
    // 8-11 未使用
    SOUL_ATTR_DEFENSE_SKILL_RATING     = 12,  // 魂防 - ITEM_MOD_DEFENSE_SKILL_RATING
    SOUL_ATTR_DODGE_RATING             = 13,  // 魂闪 - ITEM_MOD_DODGE_RATING
    SOUL_ATTR_PARRY_RATING             = 14,  // 魂招 - ITEM_MOD_PARRY_RATING
    SOUL_ATTR_BLOCK_RATING             = 15,  // 魂挡 - ITEM_MOD_BLOCK_RATING
    SOUL_ATTR_HIT_MELEE_RATING         = 16,  // 魂近命 - ITEM_MOD_HIT_MELEE_RATING
    SOUL_ATTR_HIT_RANGED_RATING        = 17,  // 魂远命 - ITEM_MOD_HIT_RANGED_RATING
    SOUL_ATTR_HIT_SPELL_RATING         = 18,  // 魂法命 - ITEM_MOD_HIT_SPELL_RATING
    SOUL_ATTR_CRIT_MELEE_RATING        = 19,  // 魂近暴 - ITEM_MOD_CRIT_MELEE_RATING
    SOUL_ATTR_CRIT_RANGED_RATING       = 20,  // 魂远暴 - ITEM_MOD_CRIT_RANGED_RATING
    SOUL_ATTR_CRIT_SPELL_RATING        = 21,  // 魂法暴 - ITEM_MOD_CRIT_SPELL_RATING
    SOUL_ATTR_HIT_TAKEN_MELEE_RATING   = 22,  // 魂近躲 - ITEM_MOD_HIT_TAKEN_MELEE_RATING
    SOUL_ATTR_HIT_TAKEN_RANGED_RATING  = 23,  // 魂远躲 - ITEM_MOD_HIT_TAKEN_RANGED_RATING
    SOUL_ATTR_HIT_TAKEN_SPELL_RATING   = 24,  // 魂法躲 - ITEM_MOD_HIT_TAKEN_SPELL_RATING
    SOUL_ATTR_CRIT_TAKEN_MELEE_RATING  = 25,  // 魂近韧 - ITEM_MOD_CRIT_TAKEN_MELEE_RATING
    SOUL_ATTR_CRIT_TAKEN_RANGED_RATING = 26,  // 魂远韧 - ITEM_MOD_CRIT_TAKEN_RANGED_RATING
    SOUL_ATTR_CRIT_TAKEN_SPELL_RATING  = 27,  // 魂法韧 - ITEM_MOD_CRIT_TAKEN_SPELL_RATING
    SOUL_ATTR_HASTE_MELEE_RATING       = 28,  // 魂近速 - ITEM_MOD_HASTE_MELEE_RATING
    SOUL_ATTR_HASTE_RANGED_RATING      = 29,  // 魂远速 - ITEM_MOD_HASTE_RANGED_RATING
    SOUL_ATTR_HASTE_SPELL_RATING       = 30,  // 魂法速 - ITEM_MOD_HASTE_SPELL_RATING
    SOUL_ATTR_HIT_RATING               = 31,  // 魂命 - ITEM_MOD_HIT_RATING
    SOUL_ATTR_CRIT_RATING              = 32,  // 魂暴 - ITEM_MOD_CRIT_RATING
    SOUL_ATTR_HIT_TAKEN_RATING         = 33,  // 魂躲 - ITEM_MOD_HIT_TAKEN_RATING
    SOUL_ATTR_CRIT_TAKEN_RATING        = 34,  // 魂韧 - ITEM_MOD_CRIT_TAKEN_RATING
    SOUL_ATTR_RESILIENCE_RATING        = 35,  // 魂韧性 - ITEM_MOD_RESILIENCE_RATING
    SOUL_ATTR_HASTE_RATING             = 36,  // 魂速 - ITEM_MOD_HASTE_RATING
    SOUL_ATTR_EXPERTISE_RATING         = 37,  // 魂准 - ITEM_MOD_EXPERTISE_RATING
    SOUL_ATTR_ATTACK_POWER             = 38,  // 魂攻 - ITEM_MOD_ATTACK_POWER
    SOUL_ATTR_RANGED_ATTACK_POWER      = 39,  // 魂远攻 - ITEM_MOD_RANGED_ATTACK_POWER
    // 40 未使用 (ITEM_MOD_FERAL_ATTACK_POWER not in 3.3)
    SOUL_ATTR_SPELL_HEALING_DONE       = 41,  // 魂疗 - ITEM_MOD_SPELL_HEALING_DONE (deprecated)
    SOUL_ATTR_SPELL_DAMAGE_DONE        = 42,  // 魂法伤 - ITEM_MOD_SPELL_DAMAGE_DONE (deprecated)
    SOUL_ATTR_MANA_REGENERATION        = 43,  // 魂蓝回 - ITEM_MOD_MANA_REGENERATION
    SOUL_ATTR_ARMOR_PENETRATION_RATING = 44,  // 魂穿 - ITEM_MOD_ARMOR_PENETRATION_RATING
    SOUL_ATTR_SPELL_POWER              = 45,  // 魂法 - ITEM_MOD_SPELL_POWER
    SOUL_ATTR_HEALTH_REGEN             = 46,  // 魂血回 - ITEM_MOD_HEALTH_REGEN
    SOUL_ATTR_SPELL_PENETRATION        = 47,  // 魂法穿 - ITEM_MOD_SPELL_PENETRATION
    SOUL_ATTR_BLOCK_VALUE              = 48,  // 魂挡值 - ITEM_MOD_BLOCK_VALUE
    // 49 未使用

    // 扩展属性 (基于 UnitMods 枚举, 使用 50+ 作为自定义ID)
    SOUL_ATTR_ARMOR                    = 50,  // 魂甲 - UNIT_MOD_ARMOR
    SOUL_ATTR_RESISTANCE_HOLY          = 51,  // 魂圣抗 - UNIT_MOD_RESISTANCE_HOLY
    SOUL_ATTR_RESISTANCE_FIRE          = 52,  // 魂火抗 - UNIT_MOD_RESISTANCE_FIRE
    SOUL_ATTR_RESISTANCE_NATURE        = 53,  // 魂自抗 - UNIT_MOD_RESISTANCE_NATURE
    SOUL_ATTR_RESISTANCE_FROST         = 54,  // 魂冰抗 - UNIT_MOD_RESISTANCE_FROST
    SOUL_ATTR_RESISTANCE_SHADOW        = 55,  // 魂暗抗 - UNIT_MOD_RESISTANCE_SHADOW
    SOUL_ATTR_RESISTANCE_ARCANE        = 56,  // 魂奥抗 - UNIT_MOD_RESISTANCE_ARCANE
    SOUL_ATTR_DAMAGE_MAINHAND          = 57,  // 魂主伤 - UNIT_MOD_DAMAGE_MAINHAND
    SOUL_ATTR_DAMAGE_OFFHAND           = 58,  // 魂副伤 - UNIT_MOD_DAMAGE_OFFHAND
    SOUL_ATTR_DAMAGE_RANGED            = 59,  // 魂远伤 - UNIT_MOD_DAMAGE_RANGED
    SOUL_ATTR_DEFENSE_VALUE            = 60,  // 魂防值 - 防御技能值

    SOUL_ATTR_MAX                      = 61   // 属性总数
};

// 魂属性中文名称数组
static const char* SoulAttributeNames[MAX_SOUL_ATTR] = {
    "魂蓝",     // 0 - 法力值
    "魂血",     // 1 - 生命值
    "",         // 2 - 未使用
    "魂敏",     // 3 - 敏捷
    "魂力",     // 4 - 力量
    "魂智",     // 5 - 智力
    "魂精",     // 6 - 精神
    "魂耐",     // 7 - 耐力
    "", "", "", "",  // 8-11 未使用
    "魂防",     // 12 - 防御等级
    "魂闪",     // 13 - 躲闪等级
    "魂招",     // 14 - 招架等级
    "魂挡",     // 15 - 格挡等级
    "魂近命",   // 16 - 近战命中等级
    "魂远命",   // 17 - 远程命中等级
    "魂法命",   // 18 - 法术命中等级
    "魂近暴",   // 19 - 近战暴击等级
    "魂远暴",   // 20 - 远程暴击等级
    "魂法暴",   // 21 - 法术暴击等级
    "魂近躲",   // 22 - 近战被命中等级
    "魂远躲",   // 23 - 远程被命中等级
    "魂法躲",   // 24 - 法术被命中等级
    "魂近韧",   // 25 - 近战被暴击等级
    "魂远韧",   // 26 - 远程被暴击等级
    "魂法韧",   // 27 - 法术被暴击等级
    "魂近速",   // 28 - 近战急速等级
    "魂远速",   // 29 - 远程急速等级
    "魂法速",   // 30 - 法术急速等级
    "魂命",     // 31 - 命中等级
    "魂暴",     // 32 - 暴击等级
    "魂躲",     // 33 - 被命中等级
    "魂韧",     // 34 - 被暴击等级
    "魂韧性",   // 35 - 韧性等级
    "魂速",     // 36 - 急速等级
    "魂准",     // 37 - 精准等级
    "魂攻",     // 38 - 攻击强度
    "魂远攻",   // 39 - 远程攻击强度
    "",         // 40 - 未使用
    "魂疗",     // 41 - 法术治疗 (deprecated)
    "魂法伤",   // 42 - 法术伤害 (deprecated)
    "魂蓝回",   // 43 - 法力回复
    "魂穿",     // 44 - 护甲穿透等级
    "魂法",     // 45 - 法术强度
    "魂血回",   // 46 - 生命值回复
    "魂法穿",   // 47 - 法术穿透
    "魂挡值",   // 48 - 格挡值
    "",         // 49 - 未使用
    // 扩展属性 (50-60)
    "魂甲",     // 50 - 护甲
    "魂圣抗",   // 51 - 神圣抗性
    "魂火抗",   // 52 - 火焰抗性
    "魂自抗",   // 53 - 自然抗性
    "魂冰抗",   // 54 - 冰霜抗性
    "魂暗抗",   // 55 - 暗影抗性
    "魂奥抗",   // 56 - 奥术抗性
    "魂主伤",   // 57 - 主手伤害
    "魂副伤",   // 58 - 副手伤害
    "魂远伤",   // 59 - 远程伤害
    "魂防值"    // 60 - 防御值
};

/**
 * @struct PlayerSoulData
 * @brief 存储玩家的魂属性数据
 */
struct PlayerSoulData
{
    uint32 playerGuid;

    // 使用数组存储所有魂属性值
    std::array<int64, MAX_SOUL_ATTR> soulValues;
    std::array<int32, MAX_SOUL_ATTR> remainderValues;

    PlayerSoulData() : playerGuid(0)
    {
        soulValues.fill(0);
        remainderValues.fill(0);
    }

    // 获取指定类型的魂属性值
    int64 GetSoulValue(uint8 type) const
    {
        if (type >= MAX_SOUL_ATTR)
            return 0;
        return soulValues[type];
    }

    // 获取指定类型的余数值
    int32 GetRemainderValue(uint8 type) const
    {
        if (type >= MAX_SOUL_ATTR)
            return 0;
        return remainderValues[type];
    }

    // 设置指定类型的魂属性值
    void SetSoulValue(uint8 type, int64 value)
    {
        if (type >= MAX_SOUL_ATTR)
            return;
        soulValues[type] = value;
    }

    // 设置指定类型的余数值
    void SetRemainderValue(uint8 type, int32 value)
    {
        if (type >= MAX_SOUL_ATTR)
            return;
        remainderValues[type] = value;
    }

    // 获取总值（魂属性 * 20亿 + 余数）
    int64 GetTotalValue(uint8 type) const
    {
        if (type >= MAX_SOUL_ATTR)
            return 0;
        return soulValues[type] * SOUL_UNIT + remainderValues[type];
    }

    // 从总值设置魂属性和余数
    void SetFromTotalValue(uint8 type, int64 totalValue)
    {
        if (type >= MAX_SOUL_ATTR)
            return;
        soulValues[type] = totalValue / SOUL_UNIT;
        remainderValues[type] = static_cast<int32>(totalValue % SOUL_UNIT);
    }
};

/**
 * @class AttributeBreakthroughMgr
 * @brief 属性突破系统管理器，单例模式
 */
class AttributeBreakthroughMgr
{
public:
    static AttributeBreakthroughMgr* instance();

    // 初始化和加载
    void LoadConfig();
    void LoadPlayerData(Player* player);
    void SavePlayerData(Player* player);
    void OnPlayerLogout(uint32 playerGuid);

    // 获取玩家数据
    PlayerSoulData* GetPlayerData(uint32 playerGuid);
    const PlayerSoulData* GetPlayerData(uint32 playerGuid) const;

    // 属性转换核心函数
    void ConvertToSoulAttribute(int64 totalValue, int64& soulValue, int32& remainder);
    int64 ConvertFromSoulAttribute(int64 soulValue, int32 remainder);
    int32 GetClientSafeValue(int64 totalValue);

    // 更新玩家的魂属性
    void UpdatePlayerSoulAttributes(Player* player);

    // 应用魂属性加成到玩家
    void ApplySoulAttributeBonus(Player* player, uint8 type, int64 bonusSoulValue);

    // 获取玩家属性的显示字符串
    std::string GetAttributeDisplayString(Player* player, uint8 type);
    std::string GetAllSoulAttributesDisplay(Player* player);

    // GM命令
    bool SetPlayerSoulAttribute(Player* player, uint8 type, int64 soulValue);
    bool AddPlayerSoulAttribute(Player* player, uint8 type, int64 addSoulValue);

    // 检查系统是否启用
    bool IsEnabled() const { return _enabled; }
    int64 GetSoulUnit() const { return SOUL_UNIT; }
    bool IsAttributeEnabled(uint8 type) const;

    // 获取属性名称
    const char* GetAttributeName(uint8 type) const;

private:
    AttributeBreakthroughMgr();
    ~AttributeBreakthroughMgr();

    bool _enabled;
    std::array<bool, MAX_SOUL_ATTR> _attributeEnabled;
    std::unordered_map<uint32, PlayerSoulData> _playerData;
};

#define sAttributeBreakthroughMgr AttributeBreakthroughMgr::instance()

#endif // _ATTRIBUTE_BREAKTHROUGH_H_
