/*
 * 属性突破系统 - 模块脚本
 */

#include "AttributeBreakthrough.h"
#include "ScriptMgr.h"
#include "Configuration/Config.h"
#include "Log.h"
#include "World.h"
#include "Player.h"
#include "Chat.h"
#include "SpellAuras.h"

// 世界脚本类，用于加载配置
class AttributeBreakthroughWorldScript : public WorldScript
{
public:
    AttributeBreakthroughWorldScript() : WorldScript("AttributeBreakthroughWorldScript"), _loaded(false), _updateTimer(0)
    {
    }

    void OnUpdate(uint32 diff) override
    {
        if (_loaded)
            return;

        _updateTimer += diff;

        // 等待1秒后加载数据
        if (_updateTimer >= 1000)
        {
            bool enabled = sConfigMgr->GetOption<bool>("AttributeBreakthrough.Enable", true);
            if (!enabled)
            {
                LOG_INFO("server.loading", ">> 属性突破系统已禁用");
                _loaded = true;
                return;
            }

            sAttributeBreakthroughMgr->LoadConfig();

            LOG_INFO("server.loading", ">> 属性突破系统加载成功");
            _loaded = true;
        }
    }

    void OnAfterConfigLoad(bool reload) override
    {
        if (reload && _loaded)
        {
            sAttributeBreakthroughMgr->LoadConfig();
            LOG_INFO("module", ">> 属性突破系统配置已重载");
        }
    }

private:
    bool _loaded;
    uint32 _updateTimer;
};

// 玩家脚本类
class AttributeBreakthroughPlayerScript : public PlayerScript
{
public:
    AttributeBreakthroughPlayerScript() : PlayerScript("AttributeBreakthroughPlayerScript") { }

    // 玩家数据加载时
    void OnPlayerLoadFromDB(Player* player) override
    {
        if (!player)
            return;

        if (!sAttributeBreakthroughMgr->IsEnabled())
            return;

        sAttributeBreakthroughMgr->LoadPlayerData(player);
    }

    // 玩家登录时显示魂属性信息
    void OnPlayerLogin(Player* player) override
    {
        if (!player)
            return;

        if (!sAttributeBreakthroughMgr->IsEnabled())
            return;

        uint32 playerGuid = player->GetGUID().GetCounter();
        const PlayerSoulData* data = sAttributeBreakthroughMgr->GetPlayerData(playerGuid);

        if (data)
        {
            // 检查是否有任何魂属性
            bool hasSoulAttr = false;
            for (int i = 0; i < SOUL_ATTR_MAX; ++i)
            {
                if (data->GetSoulValue(static_cast<SoulAttributeType>(i)) > 0)
                {
                    hasSoulAttr = true;
                    break;
                }
            }

            if (hasSoulAttr)
            {
                ChatHandler(player->GetSession()).PSendSysMessage("|cff00ff00[属性突破]|r 你拥有魂属性加成，使用 |cffffd700.soul info|r 查看详情");
            }
        }
    }

    // 玩家登出时保存数据
    void OnPlayerLogout(Player* player) override
    {
        if (!player)
            return;

        if (!sAttributeBreakthroughMgr->IsEnabled())
            return;

        uint32 playerGuid = player->GetGUID().GetCounter();

        // 保存玩家数据
        sAttributeBreakthroughMgr->SavePlayerData(player);

        // 清理内存数据
        sAttributeBreakthroughMgr->OnPlayerLogout(playerGuid);
    }

    // 属性更新后检查是否需要转换为魂属性
    void OnPlayerAfterUpdateStat(Player* player, Stats stat, float& value) override
    {
        if (!player || !sAttributeBreakthroughMgr->IsEnabled())
            return;

        uint32 playerGuid = player->GetGUID().GetCounter();
        PlayerSoulData* data = sAttributeBreakthroughMgr->GetPlayerData(playerGuid);
        if (!data)
            return;

        // 将魂属性对应的类型映射
        SoulAttributeType soulType;
        switch (stat)
        {
            case STAT_STRENGTH:  soulType = SOUL_ATTR_STRENGTH; break;
            case STAT_AGILITY:   soulType = SOUL_ATTR_AGILITY; break;
            case STAT_STAMINA:   soulType = SOUL_ATTR_STAMINA; break;
            case STAT_INTELLECT: soulType = SOUL_ATTR_INTELLECT; break;
            case STAT_SPIRIT:    soulType = SOUL_ATTR_SPIRIT; break;
            default: return;
        }

        // 获取魂属性加成
        int64 soulValue = data->GetSoulValue(soulType);
        if (soulValue > 0)
        {
            // 魂属性加成 = 魂值 * 20亿
            // 但由于客户端限制，我们只能显示最大int32
            // 实际伤害计算时会使用完整值
            int64 totalBonus = soulValue * SOUL_UNIT;

            // 将加成添加到当前值（但限制在int32范围内用于显示）
            int64 newValue = static_cast<int64>(value) + totalBonus;
            value = static_cast<float>(sAttributeBreakthroughMgr->GetClientSafeValue(newValue));
        }
    }

    // 生命值更新后应用魂血加成
    void OnPlayerAfterUpdateMaxHealth(Player* player, float& value) override
    {
        if (!player || !sAttributeBreakthroughMgr->IsEnabled())
            return;

        uint32 playerGuid = player->GetGUID().GetCounter();
        PlayerSoulData* data = sAttributeBreakthroughMgr->GetPlayerData(playerGuid);
        if (!data)
            return;

        int64 soulHealth = data->GetSoulValue(SOUL_ATTR_HEALTH);
        if (soulHealth > 0)
        {
            int64 totalBonus = soulHealth * SOUL_UNIT;
            int64 newValue = static_cast<int64>(value) + totalBonus;
            value = static_cast<float>(sAttributeBreakthroughMgr->GetClientSafeValue(newValue));
        }
    }

    // 法力值更新后应用魂蓝加成
    void OnPlayerAfterUpdateMaxPower(Player* player, Powers& power, float& value) override
    {
        if (!player || !sAttributeBreakthroughMgr->IsEnabled())
            return;

        if (power != POWER_MANA)
            return;

        uint32 playerGuid = player->GetGUID().GetCounter();
        PlayerSoulData* data = sAttributeBreakthroughMgr->GetPlayerData(playerGuid);
        if (!data)
            return;

        int64 soulMana = data->GetSoulValue(SOUL_ATTR_MANA);
        if (soulMana > 0)
        {
            int64 totalBonus = soulMana * SOUL_UNIT;
            int64 newValue = static_cast<int64>(value) + totalBonus;
            value = static_cast<float>(sAttributeBreakthroughMgr->GetClientSafeValue(newValue));
        }
    }

    // 护甲更新后应用魂甲加成
    void OnPlayerAfterUpdateArmor(Player* player, float& value) override
    {
        if (!player || !sAttributeBreakthroughMgr->IsEnabled())
            return;

        uint32 playerGuid = player->GetGUID().GetCounter();
        PlayerSoulData* data = sAttributeBreakthroughMgr->GetPlayerData(playerGuid);
        if (!data)
            return;

        int64 soulArmor = data->GetSoulValue(SOUL_ATTR_ARMOR);
        if (soulArmor > 0)
        {
            int64 totalBonus = soulArmor * SOUL_UNIT;
            int64 newValue = static_cast<int64>(value) + totalBonus;
            value = static_cast<float>(sAttributeBreakthroughMgr->GetClientSafeValue(newValue));
        }
    }

    // 攻击强度更新后应用魂攻加成
    void OnPlayerAfterUpdateAttackPowerAndDamage(Player* player, float& level, float& base_attPower,
        float& attPowerMod, float& attPowerMultiplier, bool ranged) override
    {
        if (!player || !sAttributeBreakthroughMgr->IsEnabled())
            return;

        uint32 playerGuid = player->GetGUID().GetCounter();
        PlayerSoulData* data = sAttributeBreakthroughMgr->GetPlayerData(playerGuid);
        if (!data)
            return;

        int64 soulAP = data->GetSoulValue(SOUL_ATTR_ATTACK_POWER);
        if (soulAP > 0)
        {
            // 将魂攻加成添加到攻击强度修正值
            int64 totalBonus = soulAP * SOUL_UNIT;
            int64 newMod = static_cast<int64>(attPowerMod) + totalBonus;
            attPowerMod = static_cast<float>(sAttributeBreakthroughMgr->GetClientSafeValue(newMod));
        }
    }

    // 法术强度和治疗强度更新后应用魂法加成
    void OnPlayerAfterUpdateSpellDamageAndHealing(Player* player, int32& healingBonus, int32 spellDamage[7]) override
    {
        if (!player || !sAttributeBreakthroughMgr->IsEnabled())
            return;

        uint32 playerGuid = player->GetGUID().GetCounter();
        PlayerSoulData* data = sAttributeBreakthroughMgr->GetPlayerData(playerGuid);
        if (!data)
            return;

        int64 soulSP = data->GetSoulValue(SOUL_ATTR_SPELL_POWER);
        if (soulSP > 0)
        {
            int64 totalBonus = soulSP * SOUL_UNIT;
            int32 safeBonus = sAttributeBreakthroughMgr->GetClientSafeValue(totalBonus);

            // 应用到治疗强度
            healingBonus = sAttributeBreakthroughMgr->GetClientSafeValue(
                static_cast<int64>(healingBonus) + totalBonus);

            // 应用到所有法术学派
            for (int i = 1; i < 7; ++i)
            {
                spellDamage[i] = sAttributeBreakthroughMgr->GetClientSafeValue(
                    static_cast<int64>(spellDamage[i]) + totalBonus);
            }
        }
    }
};

// 单位脚本类，用于处理伤害计算
class AttributeBreakthroughUnitScript : public UnitScript
{
public:
    AttributeBreakthroughUnitScript() : UnitScript("AttributeBreakthroughUnitScript") { }

    // 伤害计算时应用魂伤加成
    void OnDamage(Unit* attacker, Unit* victim, uint32& damage) override
    {
        if (!attacker || !sAttributeBreakthroughMgr->IsEnabled())
            return;

        Player* player = attacker->ToPlayer();
        if (!player)
            return;

        uint32 playerGuid = player->GetGUID().GetCounter();
        PlayerSoulData* data = sAttributeBreakthroughMgr->GetPlayerData(playerGuid);
        if (!data)
            return;

        int64 soulDamage = data->GetSoulValue(SOUL_ATTR_DAMAGE);
        if (soulDamage > 0)
        {
            // 魂伤加成：每点魂伤增加20亿伤害
            // 但实际伤害需要合理计算，这里使用百分比加成
            // 1魂伤 = 伤害 * 2 (100%加成)
            double damageMultiplier = 1.0 + (soulDamage * 1.0); // 每点魂伤+100%伤害
            damage = static_cast<uint32>(damage * damageMultiplier);
        }
    }
};

// 添加脚本
void AddSC_AttributeBreakthroughModule()
{
    new AttributeBreakthroughWorldScript();
    new AttributeBreakthroughPlayerScript();
    new AttributeBreakthroughUnitScript();
}
